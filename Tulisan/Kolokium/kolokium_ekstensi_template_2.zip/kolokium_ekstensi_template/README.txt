Template makalah kolokium
   File utama : kolokium_ekstensi.tex
   File yang harus diedit adalah:
    (1) kolokium_information.tex -- identitas makalah kolokium
    (2) abstrak.tex
    (3) pendahuluan.tex
    (4) metode.tex
    (5) daftar_pustaka.tex
    
